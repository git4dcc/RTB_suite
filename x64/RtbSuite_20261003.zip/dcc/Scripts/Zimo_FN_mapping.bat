@echo off
::
:: Zimo F0/F1/F2/F3/F4 Light Mapping
::
:: Usage: script.bat <uid>
:: 

setlocal enabledelayedexpansion
set "RTB_CLIENT=..\rtbclient.exe"

if "%~1"=="" (
    echo. 
    echo *** Usage: script.bat UID
    echo *** ERROR: Decoder UID parameter missing!
	echo.
	echo UIDs available
	"%RTB_CLIENT%" decoder
    exit /b 1
)

choice /C YN /M "Do you want to set the Zimo light mapping (Y/N)"

:: ERRORLEVEL checking (descending!)
if errorlevel 2 exit /b 1

call :POM 33 0 %1
call :POM 34 0 %1
call :POM 35 0 %1
call :POM 36 0 %1
call :POM 37 0 %1
call :POM 38 0 %1

call :POM 430   4 %1
call :POM 431 157 %1
call :POM 432   1 %1
call :POM 433   2 %1
call :POM 434   1 %1
call :POM 435   2 %1

call :POM 436   4 %1
call :POM 437  29 %1
call :POM 438 206 %1
call :POM 439 207 %1
call :POM 440 206 %1
call :POM 441 207 %1

call :POM 442   3 %1
call :POM 443 157 %1
call :POM 444  14 %1
call :POM 445  15 %1
call :POM 446  14 %1
call :POM 447  15 %1

call :POM 448   2 %1
call :POM 449   0 %1
call :POM 450 193 %1
call :POM 451   0 %1
call :POM 452 207 %1
call :POM 453   0 %1

call :POM 454   1 %1
call :POM 455   0 %1
call :POM 456 206 %1
call :POM 457   0 %1
call :POM 458 194 %1
call :POM 459   0 %1

call :POM 460  29 %1
call :POM 461   0 %1
call :POM 462  14 %1
call :POM 463   1 %1
call :POM 464  15 %1
call :POM 465   2 %1

::
:: List CV summary
::

"%RTB_CLIENT%" pom --cv=33 --cnt=6 "%1"
"%RTB_CLIENT%" pom --cv=430 --cnt=36 "%1"

exit /b 0

:::::::::::: SUBROUTINE ::::::::::::

:POM

echo POM %3.CV[%1] = %2
"%RTB_CLIENT%" pom --cv="%1" --val="%2" "%3"  >nul 2>&1
::timeout /t 1 /nobreak >nul
exit /b 0
